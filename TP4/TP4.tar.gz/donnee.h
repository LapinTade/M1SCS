struct data {
	int op1;
	int op2;
	int operateur;
} typedef Data;

struct Resultat {
	int result;
	int error;
} typedef Resultat;
